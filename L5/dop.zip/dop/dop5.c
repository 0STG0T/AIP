#include <stdio.h>
#include <stdlib.h>

#define MAX 1000 

// Добавление элемента в очередь
void add(int q[], int *r, int v) {
    if (*r < MAX) {
        q[(*r)++] = v;
    } else {
        printf("Ошибка: очередь переполнена!\n");
    }
}

// Вывод очереди на экран
void print(int q[], int r) {
    for (int i = 0; i < r; i++) {
        printf("%d ", q[i]);
    }
    printf("\n");
}

int main() {
    const char *f = "numbers.bin"; // Имя файла
    int C;

    // Считываем число C
    printf("Введите число C: ");
    if (scanf("%d", &C) != 1) {
        printf("Ошибка: введите целое число!\n");
        return 1;
    }

    // Очереди для чисел
    int l[MAX] = {0}; // Меньше C
    int g[MAX] = {0}; // Больше или равно C
    int rl = 0; // Указатель конца очереди l
    int rg = 0; // Указатель конца очереди g

    // Открываем файл
    FILE *file = fopen(f, "rb");
    if (!file) {
        printf("Ошибка: не удалось открыть файл '%s'!\n", f);
        return 1;
    }

    int n;
    while (fread(&n, sizeof(int), 1, file) == 1) { // Читаем числа
        if (n < C) {
            add(l, &rl, n); // Добавляем в очередь l
        } else {
            add(g, &rg, n); // Добавляем в очередь g
        }
    }

    fclose(file); // Закрываем файл

    // Вывод результатов
    printf("Числа меньше %d:\n", C);
    print(l, rl);

    printf("Остальные числа:\n");
    print(g, rg);

    return 0;
}