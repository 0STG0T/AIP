#include <stdio.h>

int main() {
    const char *filename = "numbers.bin";
    FILE *file = fopen(filename, "wb"); // Открываем файл для записи в бинарном режиме
    if (file == NULL) {
        printf("Ошибка: не удалось создать файл '%s'!\n", filename);
        return 1;
    }

    int numbers[] = {1, 5, 3, 7, 2}; // Числа для записи в файл
    fwrite(numbers, sizeof(int), 5, file); // Записываем числа в файл

    fclose(file); // Закрываем файл
    printf("Файл '%s' успешно создан.\n", filename);
    return 0;
}